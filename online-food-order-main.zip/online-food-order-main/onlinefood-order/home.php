<?php include('partials-front/menu.php'); ?>



    <!-- CAtegories Section Starts Here -->
    <section class="home">
    <img src="images\ulimited.jpg" alt="Beer Image" class="beer-image">
  <div class="buttons-container">
    <button class="menu-button"><a href="<?php echo  SITEURL;?>categories.php">Menu</a></button>
    <button class="order-button"><a href="<?php echo SITEURL;?>foods.php">Make Order</a></button>
  </div>
  <div class="details-container">
    <div class="details">
      <h2>IGNYT - The Beer Station</h2>
      <div class="ratings">5/5 | 3 Reviews</div>
      <div class="location">Kumaraswamy Layout, South Bengaluru</div>
      <div class="price-cuisine">₹ 700 for two approx | Multicuisine</div>
      <div class="opening-hours">Open from 11:00 AM - 11:00 PM</div>
    </div>
  </div>
    </section>
    <!-- Categories Section Ends Here -->


    <?php include('partials-front/footer.php'); ?>